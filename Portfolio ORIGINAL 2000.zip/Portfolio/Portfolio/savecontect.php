<?php
// save_contact.php - Processa e salva os dados do formulário

// Headers para JSON e CORS
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Inclui arquivo de configuração
require_once 'config.php';

// Função para enviar resposta JSON
function sendResponse($success, $message, $data = null) {
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Verifica se é POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendResponse(false, 'Método não permitido. Use POST.');
}

// Recebe e decodifica JSON (se enviado como JSON)
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Se não for JSON, pega do POST normal
if (!$data) {
    $data = $_POST;
}

// Validação dos campos obrigatórios
if (empty($data['name']) || empty($data['email']) || 
    empty($data['subject']) || empty($data['message'])) {
    sendResponse(false, 'Todos os campos são obrigatórios.');
}

// Sanitiza os dados
$nome = sanitizeInput($data['name']);
$email = sanitizeInput($data['email']);
$assunto = sanitizeInput($data['subject']);
$mensagem = sanitizeInput($data['message']);

// Validações específicas
if (strlen($nome) < 3 || strlen($nome) > 100) {
    sendResponse(false, 'Nome deve ter entre 3 e 100 caracteres.');
}

if (!isValidEmail($email)) {
    sendResponse(false, 'Email inválido.');
}

if (strlen($assunto) < 3 || strlen($assunto) > 200) {
    sendResponse(false, 'Assunto deve ter entre 3 e 200 caracteres.');
}

if (strlen($mensagem) < 10 || strlen($mensagem) > 5000) {
    sendResponse(false, 'Mensagem deve ter entre 10 e 5000 caracteres.');
}

// Captura IP do visitante
$ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Desconhecido';

// Conecta ao banco de dados
$conn = getConnection();

if (!$conn) {
    sendResponse(false, 'Erro ao conectar ao banco de dados.');
}

// Prepara statement para evitar SQL Injection
$stmt = $conn->prepare(
    "INSERT INTO contatos (nome, email, assunto, mensagem, ip_address) 
     VALUES (?, ?, ?, ?, ?)"
);

if (!$stmt) {
    $conn->close();
    sendResponse(false, 'Erro ao preparar consulta: ' . $conn->error);
}

// Bind dos parâmetros
$stmt->bind_param("sssss", $nome, $email, $assunto, $mensagem, $ip_address);

// Executa a inserção
if ($stmt->execute()) {
    $insert_id = $stmt->insert_id;
    
    $stmt->close();
    $conn->close();
    
    // Opcional: Enviar email de notificação
    // sendEmailNotification($nome, $email, $assunto, $mensagem);
    
    sendResponse(true, 'Mensagem enviada com sucesso!', [
        'id' => $insert_id,
        'nome' => $nome
    ]);
} else {
    $error = $stmt->error;
    $stmt->close();
    $conn->close();
    
    error_log("Erro ao inserir contato: " . $error);
    sendResponse(false, 'Erro ao salvar mensagem. Tente novamente.');
}

// Função opcional para enviar email de notificação
function sendEmailNotification($nome, $email, $assunto, $mensagem) {
    $to = "migspaternoster@gmail.com";
    $subject = "Nova mensagem do portfólio: " . $assunto;
    $body = "Nome: $nome\n";
    $body .= "Email: $email\n";
    $body .= "Assunto: $assunto\n\n";
    $body .= "Mensagem:\n$mensagem";
    
    $headers = "From: noreply@seusite.com\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    
    mail($to, $subject, $body, $headers);
}
?>